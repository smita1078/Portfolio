"""
Tests for the Prisma owner rule engine. Run with: pytest tests/test_owner_engine.py -v

These specifically test the priority-ordering behavior that caused confusion
during design (whm/fwt and whm/recon must fire before the general whm rule).
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.rules.owner_engine import (
    apply_base_rules,
    apply_override_rules,
    resolve_owner,
    SEED_BASE_RULES,
    SEED_OVERRIDE_RULES,
)


def test_base_rule_fatca_match():
    path = "com/db/taxtech/fatca/some-service"
    assert apply_base_rules(path, SEED_BASE_RULES) == "FATCA"


def test_base_rule_no_match_falls_through():
    path = "com/db/somethingelse/service"
    assert apply_base_rules(path, SEED_BASE_RULES) is None


def test_override_whm_fwt_beats_general_whm():
    """The critical case: whm/fwt must resolve to USTax, NOT the general whm->WHM rule."""
    path = "com/db/taxtech/whm/fwt/service"
    owner, rule = apply_override_rules(path, language=None, base_owner="WHM", override_rules=SEED_OVERRIDE_RULES)
    assert owner == "USTax"
    assert "whm/fwt" in rule


def test_override_whm_recon_beats_general_whm():
    path = "com/db/taxtech/whm/recon/service"
    owner, rule = apply_override_rules(path, language=None, base_owner="WHM", override_rules=SEED_OVERRIDE_RULES)
    assert owner == "USTax"
    assert "whm/recon" in rule


def test_override_general_whm_when_no_specific_match():
    path = "com/db/taxtech/whm/other-service"
    owner, rule = apply_override_rules(path, language=None, base_owner="WHM", override_rules=SEED_OVERRIDE_RULES)
    assert owner == "WHM"  # pending team confirmation - see open items
    assert "whm" in rule


def test_override_language_go_forces_devops():
    path = "com/db/taxtech/fatca/some-service"  # would otherwise be FATCA
    owner, rule = apply_override_rules(path, language="Go", base_owner="FATCA", override_rules=SEED_OVERRIDE_RULES)
    assert owner == "DevOps"


def test_full_pipeline_manual_override_wins_over_everything():
    resolution = resolve_owner(
        repository_path="com/db/taxtech/fatca/weird-one-off-repo",
        language=None,
        base_rules=SEED_BASE_RULES,
        override_rules=SEED_OVERRIDE_RULES,
        manual_overrides={"com/db/taxtech/fatca/weird-one-off-repo": "TDL"},
    )
    assert resolution.final_owner == "TDL"
    assert resolution.base_owner == "FATCA"  # preserved for audit, even though overridden
    assert "manual_override" in resolution.override_applied


def test_full_pipeline_no_match_defaults_to_devops():
    resolution = resolve_owner(
        repository_path="com/db/unknown-team/service",
        language=None,
        base_rules=SEED_BASE_RULES,
        override_rules=SEED_OVERRIDE_RULES,
        manual_overrides={},
    )
    assert resolution.final_owner == "DevOps"


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
