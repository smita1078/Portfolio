"""
Run once to populate owner_base_rule and owner_override_rule with the rules
confirmed so far. Run again (safe to re-run - it clears and re-inserts) whenever
rules change, or build the admin UI to edit these directly later.

Usage: python -m app.services.seed_rules
"""
from app.database import SessionLocal, engine, Base
from app.models.owner_rules import OwnerBaseRule, OwnerOverrideRule
from app.rules.owner_engine import SEED_BASE_RULES, SEED_OVERRIDE_RULES


def seed():
    Base.metadata.create_all(bind=engine)  # creates tables if they don't exist yet
    db = SessionLocal()
    try:
        db.query(OwnerBaseRule).delete()
        db.query(OwnerOverrideRule).delete()

        for r in SEED_BASE_RULES:
            db.add(OwnerBaseRule(
                pattern=r["pattern"],
                match_type=r["match_type"],
                business_unit=r["business_unit"],
                priority=r["priority"],
                active=r["active"],
                created_by="seed_script",
            ))

        for r in SEED_OVERRIDE_RULES:
            db.add(OwnerOverrideRule(
                condition_type=r["condition_type"],
                condition_value=r["condition_value"],
                override_owner=r["override_owner"],
                priority=r["priority"],
                active=r["active"],
                created_by="seed_script",
            ))

        db.commit()
        print(f"Seeded {len(SEED_BASE_RULES)} base rules and {len(SEED_OVERRIDE_RULES)} override rules.")
        print("NOTE: the general 'whm' -> WHM override rule is still pending final "
              "confirmation from the team (see architecture doc open items) - update "
              "app/rules/owner_engine.py SEED_OVERRIDE_RULES and re-run this script once confirmed.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
