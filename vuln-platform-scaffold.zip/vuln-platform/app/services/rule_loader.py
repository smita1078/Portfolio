"""
Loads owner rules from the DB into the plain list/dict shapes that
app/rules/owner_engine.py functions expect (keeps the rule engine itself
free of any DB/ORM dependency, so it stays easy to unit test).
"""
from sqlalchemy.orm import Session
from app.models.owner_rules import OwnerBaseRule, OwnerOverrideRule, PrismaOwnerManualOverride


def load_base_rules(db: Session) -> list[dict]:
    rules = db.query(OwnerBaseRule).filter(OwnerBaseRule.active == True).order_by(OwnerBaseRule.priority).all()
    return [
        {
            "pattern": r.pattern,
            "match_type": r.match_type,
            "business_unit": r.business_unit,
            "priority": r.priority,
            "active": r.active,
        }
        for r in rules
    ]


def load_override_rules(db: Session) -> list[dict]:
    rules = db.query(OwnerOverrideRule).filter(OwnerOverrideRule.active == True).order_by(OwnerOverrideRule.priority).all()
    return [
        {
            "condition_type": r.condition_type,
            "condition_value": r.condition_value,
            "override_owner": r.override_owner,
            "priority": r.priority,
            "active": r.active,
        }
        for r in rules
    ]


def load_manual_overrides(db: Session) -> dict:
    overrides = db.query(PrismaOwnerManualOverride).all()
    return {o.repository: o.override_owner for o in overrides}
