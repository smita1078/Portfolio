"""
oss_component_snapshot: one row per component from VersionInstances/ComponentRemediations
("Composite Viewer"). This source is pre-aggregated - it already reports counts per
severity per component, not one-row-per-vulnerability like CM/Prisma. Owner is fully
formula-derived here, no manual override table needed (per team confirmation).
"""
from sqlalchemy import Column, Integer, String, ForeignKey, JSON
from app.database import Base


class OSSComponentSnapshot(Base):
    __tablename__ = "oss_component_snapshot"

    id = Column(Integer, primary_key=True)
    scan_batch_id = Column(Integer, ForeignKey("scan_batch.id"), nullable=False)

    component_name = Column(String)            # 'Component Name'
    component_version = Column(String)         # 'Version'
    component_instance_path = Column(String, index=True)  # 'Component Instance Path'
    owner = Column(String)                     # formula-derived, no override needed

    critical_count = Column(Integer, default=0)  # 'compVulCriticalCountField'
    high_count = Column(Integer, default=0)       # 'compVulHighCountField'
    medium_count = Column(Integer, default=0)     # 'compVulMediumCountField'
    low_count = Column(Integer, default=0)        # 'compVulLowCountField'
    unknown_count = Column(Integer, default=0)    # 'compVulUnknownCountField'

    max_vuln_rating = Column(String)
    binary_url = Column(String)

    natural_key = Column(String, index=True)   # component_instance_path + component_name + version

    raw_payload = Column(JSON)
