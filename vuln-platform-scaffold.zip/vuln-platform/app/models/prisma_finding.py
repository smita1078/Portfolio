"""
prisma_finding: one row per finding from Prisma_Report.
Severity AND owner analysis - owner goes through the base rule + override pipeline.

base_owner and final_owner are BOTH kept (not just the final answer) so you can
always audit "why is this repo tagged X" - matters for a bank, and for your own
sanity six months from now.
"""
from sqlalchemy import Column, Integer, String, Date, ForeignKey, JSON
from app.database import Base


class PrismaFinding(Base):
    __tablename__ = "prisma_finding"

    id = Column(Integer, primary_key=True)
    scan_batch_id = Column(Integer, ForeignKey("scan_batch.id"), nullable=False)

    repository = Column(String, index=True)   # 'Repository'
    cve_id = Column(String)                   # 'CVE ID'
    severity_raw = Column(String)             # 'Severity'
    severity_normalized = Column(String)      # derived

    risk_score = Column(String)               # 'CVSS'
    package_name = Column(String)             # 'Package'
    package_version = Column(String)          # 'Version'
    fix_status = Column(String)               # 'Fix Status'
    status = Column(String)                   # derived: open | resolved

    language = Column(String)                 # 'Language' - drives DevOps override rule

    # --- owner derivation pipeline (this is the important part) ---
    base_owner = Column(String)               # stage 1: result of owner_base_rule pattern match
    final_owner = Column(String)              # after override rules applied - THIS is what pivots use
    owner_override_applied = Column(String, nullable=True)  # which rule (if any) fired, for audit

    natural_key = Column(String, index=True)  # repository + cve_id + package + version

    raw_payload = Column(JSON)
