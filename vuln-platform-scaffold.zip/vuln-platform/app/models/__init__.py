"""
Import all models here so that Base.metadata.create_all() (and Alembic's
autogenerate) can discover every table in one place.
"""
from app.models.scan_batch import ScanBatch
from app.models.cm_finding import CMFinding
from app.models.prisma_finding import PrismaFinding
from app.models.oss_snapshot import OSSComponentSnapshot
from app.models.owner_rules import OwnerBaseRule, OwnerOverrideRule, PrismaOwnerManualOverride
from app.models.weekly_analysis import (
    CMWeeklySnapshot, CMWeeklyDelta,
    PrismaWeeklySnapshot, PrismaWeeklyDelta,
    OSSWeeklySnapshot, OSSWeeklyDelta,
)
from app.models.audit_log import IngestionAuditLog

__all__ = [
    "ScanBatch",
    "CMFinding",
    "PrismaFinding",
    "OSSComponentSnapshot",
    "OwnerBaseRule",
    "OwnerOverrideRule",
    "PrismaOwnerManualOverride",
    "CMWeeklySnapshot",
    "CMWeeklyDelta",
    "PrismaWeeklySnapshot",
    "PrismaWeeklyDelta",
    "OSSWeeklySnapshot",
    "OSSWeeklyDelta",
    "IngestionAuditLog",
]
