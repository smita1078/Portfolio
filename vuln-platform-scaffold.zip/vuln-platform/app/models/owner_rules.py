"""
Owner derivation rule tables for Prisma. This replaces the manual Excel process:
  1. owner_base_rule    - the original SEARCH() formula, as data (path pattern -> team)
  2. owner_override_rule - the manual overrides (language=Go -> DevOps, whm/fwt -> USTax, etc),
                            as priority-ordered rules instead of hand-editing cells each week
  3. prisma_owner_manual_override - true one-off exceptions that don't fit any pattern

All three are editable via an admin UI later, with created_by/created_at for audit.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, func
from app.database import Base


class OwnerBaseRule(Base):
    """Stage 1: path substring/regex -> base team. Mirrors the original SEARCH() formula."""
    __tablename__ = "owner_base_rule"

    id = Column(Integer, primary_key=True)
    pattern = Column(String, nullable=False)          # e.g. 'taxtech/fatca'
    match_type = Column(String, default="substring")  # 'substring' | 'regex'
    business_unit = Column(String, nullable=False)    # 'FATCA', 'WHM', 'TDL', 'USTax', 'DevOps'
    priority = Column(Integer, nullable=False)        # first match wins
    active = Column(Boolean, default=True)
    created_by = Column(String)
    created_at = Column(DateTime, server_default=func.now())


class OwnerOverrideRule(Base):
    """
    Stage 2: overrides applied on top of the base rule result.
    IMPORTANT: priority must put more-specific path matches BEFORE general ones
    (e.g. 'whm/fwt' and 'whm/recon' must be checked before the general 'whm' rule,
    or the general rule will match first and the specific ones never fire).
    """
    __tablename__ = "owner_override_rule"

    id = Column(Integer, primary_key=True)
    condition_type = Column(String, nullable=False)   # 'path_contains' | 'language_equals'
    condition_value = Column(String, nullable=False)  # e.g. 'whm/fwt', 'Go'
    override_owner = Column(String, nullable=False)   # resulting owner value
    priority = Column(Integer, nullable=False)        # evaluation order, first match wins
    active = Column(Boolean, default=True)
    created_by = Column(String)
    created_at = Column(DateTime, server_default=func.now())


class PrismaOwnerManualOverride(Base):
    """
    Stage 3: true one-off exceptions for repos that don't fit any pattern.
    Lets someone fix a single misclassified repo from the UI without writing
    a new regex (and redeploying) for one case.
    """
    __tablename__ = "prisma_owner_manual_override"

    id = Column(Integer, primary_key=True)
    repository = Column(String, nullable=False, index=True)
    override_owner = Column(String, nullable=False)
    reason = Column(String, nullable=True)
    overridden_by = Column(String, nullable=True)
    overridden_at = Column(DateTime, server_default=func.now())
