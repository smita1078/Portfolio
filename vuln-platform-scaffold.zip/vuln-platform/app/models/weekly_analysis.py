"""
Per-source weekly snapshot + delta tables. Kept separate per source (not merged)
per the "no cross-source joins needed" decision. These are computed after each
ingestion, not sourced from a report column directly - see app/services/weekly_analysis.py.
"""
from sqlalchemy import Column, Integer, String, Date, Float
from app.database import Base


class CMWeeklySnapshot(Base):
    __tablename__ = "cm_weekly_snapshot"
    id = Column(Integer, primary_key=True)
    report_date = Column(Date, nullable=False, index=True)
    severity_normalized = Column(String, nullable=False)
    open_count = Column(Integer, default=0)


class CMWeeklyDelta(Base):
    __tablename__ = "cm_weekly_delta"
    id = Column(Integer, primary_key=True)
    report_date = Column(Date, nullable=False, index=True)
    prior_report_date = Column(Date, nullable=False)
    severity_normalized = Column(String, nullable=False)
    new_count = Column(Integer, default=0)
    fixed_count = Column(Integer, default=0)
    still_open_count = Column(Integer, default=0)
    pct_improvement = Column(Float, nullable=True)


class PrismaWeeklySnapshot(Base):
    __tablename__ = "prisma_weekly_snapshot"
    id = Column(Integer, primary_key=True)
    report_date = Column(Date, nullable=False, index=True)
    severity_normalized = Column(String, nullable=False)
    owner = Column(String, nullable=False)
    open_count = Column(Integer, default=0)


class PrismaWeeklyDelta(Base):
    __tablename__ = "prisma_weekly_delta"
    id = Column(Integer, primary_key=True)
    report_date = Column(Date, nullable=False, index=True)
    prior_report_date = Column(Date, nullable=False)
    severity_normalized = Column(String, nullable=False)
    owner = Column(String, nullable=False)
    new_count = Column(Integer, default=0)
    fixed_count = Column(Integer, default=0)
    still_open_count = Column(Integer, default=0)
    pct_improvement = Column(Float, nullable=True)


class OSSWeeklySnapshot(Base):
    __tablename__ = "oss_weekly_snapshot"
    id = Column(Integer, primary_key=True)
    report_date = Column(Date, nullable=False, index=True)
    severity_normalized = Column(String, nullable=False)
    owner = Column(String, nullable=False)
    open_count = Column(Integer, default=0)


class OSSWeeklyDelta(Base):
    __tablename__ = "oss_weekly_delta"
    id = Column(Integer, primary_key=True)
    report_date = Column(Date, nullable=False, index=True)
    prior_report_date = Column(Date, nullable=False)
    severity_normalized = Column(String, nullable=False)
    owner = Column(String, nullable=False)
    new_count = Column(Integer, default=0)
    fixed_count = Column(Integer, default=0)
    still_open_count = Column(Integer, default=0)
    pct_improvement = Column(Float, nullable=True)
