"""
cm_finding: one row per finding from CM_Report (Tanium/Defender host scans).
Severity-only analysis, per team's confirmation - no owner/team dimension here.
"""
from sqlalchemy import Column, Integer, String, Date, ForeignKey, JSON
from app.database import Base


class CMFinding(Base):
    __tablename__ = "cm_finding"

    id = Column(Integer, primary_key=True)
    scan_batch_id = Column(Integer, ForeignKey("scan_batch.id"), nullable=False)

    # identity columns, from CM_Report sheet
    source_finding_id = Column(String)       # 'Finding ID'
    resource_name = Column(String)           # 'Resource Name' (hostname)
    nar_id = Column(String)                  # 'NAR ID'
    application_name = Column(String)        # 'Application Name'

    cve_id = Column(String)                  # 'Tagged CVEs'
    severity_raw = Column(String)            # 'Priority Level'
    severity_normalized = Column(String)     # derived: Critical/High/Medium/Low

    risk_score = Column(String)              # 'Risk Score'
    status = Column(String)                  # derived: open | resolved
    remediation_status = Column(String)      # 'Remediation Status'
    cm_stage = Column(String)                # 'CM Current Stage'
    exception_status = Column(String)        # 'Exception Status'
    exception_type = Column(String)          # 'Exception Type'
    ticket_reference = Column(String)        # 'SNOW Ticket Reference Number'

    due_date = Column(Date)                  # 'Due Date'
    last_found_date = Column(Date)           # 'Last Found Date'

    # stable identity across weeks, used to compute new/fixed/still-open
    natural_key = Column(String, index=True)  # built from cve_id + resource_name

    raw_payload = Column(JSON)               # full original row, for traceability/audit
