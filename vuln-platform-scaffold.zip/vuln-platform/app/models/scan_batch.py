"""
scan_batch: one row per weekly file upload, per source.
Everything else (cm_finding, prisma_finding, oss_component_snapshot) links back to this.
"""
from sqlalchemy import Column, Integer, String, Date, DateTime, func
from app.database import Base


class ScanBatch(Base):
    __tablename__ = "scan_batch"

    id = Column(Integer, primary_key=True)
    source = Column(String, nullable=False)  # 'cm' | 'prisma' | 'oss'
    report_date = Column(Date, nullable=False)  # the week this batch represents
    file_name = Column(String, nullable=False)
    uploaded_by = Column(String, nullable=True)
    uploaded_at = Column(DateTime, server_default=func.now())
    raw_file_ref = Column(String, nullable=True)  # path to the stored original xlsx
    row_count = Column(Integer, nullable=True)
    status = Column(String, default="processing")  # processing | completed | failed
