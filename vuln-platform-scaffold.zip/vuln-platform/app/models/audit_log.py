"""
ingestion_audit_log: compliance requirement. Logs every upload, every rule change,
every manual override - who did what, when.
"""
from sqlalchemy import Column, Integer, String, DateTime, JSON, func
from app.database import Base


class IngestionAuditLog(Base):
    __tablename__ = "ingestion_audit_log"

    id = Column(Integer, primary_key=True)
    scan_batch_id = Column(Integer, nullable=True)
    action = Column(String, nullable=False)   # 'upload' | 'mapping_confirmed' | 'rule_changed' | etc.
    actor = Column(String, nullable=True)
    timestamp = Column(DateTime, server_default=func.now())
    detail = Column(JSON, nullable=True)
