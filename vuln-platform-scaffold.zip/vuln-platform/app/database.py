"""
Database connection setup.

Uses SQLite by default (a local file, no server needed - runs anywhere Python runs).
To move to Postgres later, only DATABASE_URL needs to change - nothing else in the
app talks to SQLite specifically, it all goes through SQLAlchemy.
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# The whole "database" is this one file. Store it wherever your company policy
# says report data (xlsx files) should live - this file will contain the same
# sensitive data.
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./vuln_platform.db")

# check_same_thread=False is needed for SQLite when used with FastAPI (multiple
# requests may use the same connection pool). Not needed once/if you move to Postgres.
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency - yields a DB session per request, closes it after."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
