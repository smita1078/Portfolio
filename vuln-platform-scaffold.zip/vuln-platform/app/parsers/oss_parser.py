"""
Parser for VersionInstances/ComponentRemediations ("Composite Viewer"). This
source is pre-aggregated (counts per component), and owner is fully
formula-derived here - no manual override table needed, per team confirmation.
"""
import pandas as pd
from app.models.oss_snapshot import OSSComponentSnapshot


def build_natural_key(component_instance_path: str, component_name: str, version: str) -> str:
    return f"{component_instance_path or ''}::{component_name or ''}::{version or ''}"


def parse_oss_report(file_path: str, scan_batch_id: int, sheet_name: str = None) -> list[OSSComponentSnapshot]:
    df = pd.read_excel(file_path, sheet_name=sheet_name) if sheet_name else pd.read_excel(file_path)

    snapshots = []
    for _, row in df.iterrows():
        component_name = row.get("Component Name")
        version = row.get("Version")
        instance_path = row.get("Component Instance Path")

        snapshot = OSSComponentSnapshot(
            scan_batch_id=scan_batch_id,
            component_name=component_name,
            component_version=version,
            component_instance_path=instance_path,
            owner=row.get("Owner"),  # formula-derived at source, used as-is
            critical_count=_safe_int(row.get("compVulCriticalCountField")),
            high_count=_safe_int(row.get("compVulHighCountField")),
            medium_count=_safe_int(row.get("compVulMediumCountField")),
            low_count=_safe_int(row.get("compVulLowCountField")),
            unknown_count=_safe_int(row.get("compVulUnknownCountField")),
            max_vuln_rating=row.get("Max Vuln Rating"),
            binary_url=row.get("Binary URL"),
            natural_key=build_natural_key(instance_path, component_name, version),
            raw_payload=row.to_dict(),
        )
        snapshots.append(snapshot)

    return snapshots


def _safe_int(value):
    if pd.isna(value):
        return 0
    try:
        return int(value)
    except (ValueError, TypeError):
        return 0
