"""
Parser for Prisma_Report. Runs each row's Repository path through the owner
rule engine (app/rules/owner_engine.py) to derive base_owner and final_owner.
"""
import pandas as pd
from datetime import datetime
from app.models.prisma_finding import PrismaFinding
from app.rules.owner_engine import resolve_owner

SEVERITY_MAP = {
    "critical": "Critical",
    "high": "High",
    "medium": "Medium",
    "low": "Low",
}


def normalize_severity(raw: str) -> str:
    if not raw:
        return "Unknown"
    return SEVERITY_MAP.get(str(raw).strip().lower(), str(raw).strip())


def build_natural_key(repository: str, cve_id: str, package: str, version: str) -> str:
    return f"{repository or ''}::{cve_id or ''}::{package or ''}::{version or ''}"


def parse_prisma_report(
    file_path: str,
    scan_batch_id: int,
    base_rules: list,
    override_rules: list,
    manual_overrides: dict,
    sheet_name: str = None,
) -> list[PrismaFinding]:
    """
    base_rules / override_rules / manual_overrides should be pre-loaded from the
    DB before calling this (see app/services/rule_loader.py) so we're not
    re-querying the DB on every row.
    """
    df = pd.read_excel(file_path, sheet_name=sheet_name) if sheet_name else pd.read_excel(file_path)

    findings = []
    for _, row in df.iterrows():
        repository = row.get("Repository")
        cve_id = row.get("CVE ID")
        package = row.get("Package")
        version = row.get("Version")
        severity_raw = row.get("Severity")
        language = row.get("Language")  # drives the DevOps override rule
        fix_status = row.get("Fix Status")

        resolution = resolve_owner(
            repository_path=repository or "",
            language=language,
            base_rules=base_rules,
            override_rules=override_rules,
            manual_overrides=manual_overrides,
        )

        finding = PrismaFinding(
            scan_batch_id=scan_batch_id,
            repository=repository,
            cve_id=cve_id,
            severity_raw=severity_raw,
            severity_normalized=normalize_severity(severity_raw),
            risk_score=row.get("CVSS"),
            package_name=package,
            package_version=version,
            fix_status=fix_status,
            status="resolved" if fix_status and "fixed" in str(fix_status).lower() else "open",
            language=language,
            base_owner=resolution.base_owner,
            final_owner=resolution.final_owner,
            owner_override_applied=resolution.override_applied,
            natural_key=build_natural_key(repository, cve_id, package, version),
            raw_payload=row.to_dict(),
        )
        findings.append(finding)

    return findings
