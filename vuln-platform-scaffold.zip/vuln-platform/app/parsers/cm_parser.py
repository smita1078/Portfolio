"""
Parser for CM_Report (Tanium/Defender host scans). Severity-only analysis per
team's confirmation - no owner/team dimension for this source.
"""
import pandas as pd
from datetime import datetime
from app.models.cm_finding import CMFinding

# Map the tool's own severity labels to our normalized scale.
# Extend this if CM starts reporting labels we haven't seen yet.
SEVERITY_MAP = {
    "critical": "Critical",
    "high": "High",
    "medium": "Medium",
    "low": "Low",
}


def normalize_severity(raw: str) -> str:
    if not raw:
        return "Unknown"
    return SEVERITY_MAP.get(str(raw).strip().lower(), str(raw).strip())


def build_natural_key(cve_id: str, resource_name: str) -> str:
    """
    Stable identity across weeks - rebuilt from CVE + hostname rather than
    trusting the tool's own Finding ID to be stable across re-scans (see
    architecture doc open item #1 - confirm with team if the tool's own ID
    is safe to use directly instead).
    """
    return f"{(cve_id or '').strip()}::{(resource_name or '').strip()}"


def parse_cm_report(file_path: str, scan_batch_id: int, sheet_name: str = None) -> list[CMFinding]:
    """
    Reads the CM_Report sheet and returns a list of CMFinding ORM objects
    (not yet committed - caller handles the DB session/commit).
    """
    df = pd.read_excel(file_path, sheet_name=sheet_name) if sheet_name else pd.read_excel(file_path)

    findings = []
    for _, row in df.iterrows():
        cve_id = row.get("Tagged CVEs")
        resource_name = row.get("Resource Name")
        severity_raw = row.get("Priority Level")

        finding = CMFinding(
            scan_batch_id=scan_batch_id,
            source_finding_id=row.get("Finding ID"),
            resource_name=resource_name,
            nar_id=row.get("NAR ID"),
            application_name=row.get("Application Name"),
            cve_id=cve_id,
            severity_raw=severity_raw,
            severity_normalized=normalize_severity(severity_raw),
            risk_score=row.get("Risk Score"),
            status="open",  # refined later by the weekly diff step (resolved if absent next batch)
            remediation_status=row.get("Remediation Status"),
            cm_stage=row.get("CM Current Stage"),
            exception_status=row.get("Exception Status"),
            exception_type=row.get("Exception Type"),
            ticket_reference=row.get("SNOW Ticket Reference Number"),
            due_date=_safe_date(row.get("Due Date")),
            last_found_date=_safe_date(row.get("Last Found Date")),
            natural_key=build_natural_key(cve_id, resource_name),
            raw_payload=row.to_dict(),
        )
        findings.append(finding)

    return findings


def _safe_date(value):
    """Excel dates come through as pandas Timestamps, NaT, or strings - normalize safely."""
    if pd.isna(value):
        return None
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.date()
    try:
        return pd.to_datetime(value).date()
    except Exception:
        return None
