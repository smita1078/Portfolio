"""
Prisma owner derivation engine.

Replaces the manual process: base formula match -> copy to static column -> hand-edit
overrides. This is the highest-risk logic in the whole app to get subtly wrong, so
it's written as small, independently testable functions rather than one big blob.

Pipeline:
  1. apply_base_rules()     - path pattern match -> base team (the original SEARCH() formula)
  2. apply_override_rules() - language/path overrides layered on top, priority-ordered
  3. apply_manual_override()- one-off exceptions from prisma_owner_manual_override table

NOTE: two things are still pending final confirmation from the team (see
architecture doc, open items):
  - what the plain 'whm' path (no /fwt or /recon) actually resolves to
  - precedence between language-based and path-based override rules when both match
The seed rules below encode the best information available so far; treat priority
values as easy to revise once those are confirmed - that's the whole point of this
being data, not code.
"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class OwnerResolution:
    """Result of running the pipeline on one finding - keeps every stage's
    output so the final answer is always auditable, not just a black-box string."""
    repository: str
    base_owner: Optional[str]
    override_applied: Optional[str]  # description of which rule fired, if any
    final_owner: str


def apply_base_rules(repository_path: str, base_rules: list) -> Optional[str]:
    """
    Stage 1: run the path against owner_base_rule entries, in priority order,
    first match wins. Mirrors the original Excel SEARCH() formula.

    base_rules: list of dicts/rows with keys: pattern, match_type, business_unit,
                priority, active - already sorted by priority ascending.
    """
    for rule in base_rules:
        if not rule["active"]:
            continue
        if rule["match_type"] == "substring":
            if rule["pattern"].lower() in repository_path.lower():
                return rule["business_unit"]
        elif rule["match_type"] == "regex":
            import re
            if re.search(rule["pattern"], repository_path, re.IGNORECASE):
                return rule["business_unit"]
    return None  # no match - falls through to the DevOps catch-all upstream


def apply_override_rules(
    repository_path: str,
    language: Optional[str],
    base_owner: Optional[str],
    override_rules: list,
) -> tuple[str, Optional[str]]:
    """
    Stage 2: apply override rules in priority order, first match wins.
    Returns (final_owner, description_of_rule_applied_or_None).

    override_rules: list of dicts with keys: condition_type, condition_value,
                     override_owner, priority, active - already sorted by priority ascending.

    IMPORTANT: priority ordering is what makes 'whm/fwt' get checked before the
    general 'whm' rule. If priorities are wrong, the specific rules silently
    never fire - this is exactly the kind of bug that's easy to introduce and
    hard to notice, so keep priority values explicit and tested.
    """
    for rule in override_rules:
        if not rule["active"]:
            continue

        if rule["condition_type"] == "path_contains":
            if rule["condition_value"].lower() in repository_path.lower():
                return rule["override_owner"], f"path_contains:{rule['condition_value']}"

        elif rule["condition_type"] == "language_equals":
            if language and language.lower() == rule["condition_value"].lower():
                return rule["override_owner"], f"language_equals:{rule['condition_value']}"

    # no override matched - base owner stands (or DevOps if base was also None)
    return (base_owner or "DevOps"), None


def apply_manual_override(repository_path: str, manual_overrides: dict) -> Optional[str]:
    """
    Stage 3: check for a one-off manual override for this exact repository.
    manual_overrides: dict of {repository: override_owner}, pre-loaded from
                       prisma_owner_manual_override table.
    """
    return manual_overrides.get(repository_path)


def resolve_owner(
    repository_path: str,
    language: Optional[str],
    base_rules: list,
    override_rules: list,
    manual_overrides: dict,
) -> OwnerResolution:
    """
    Runs the full 3-stage pipeline for one finding. This is the function the
    Prisma parser calls per row.
    """
    base_owner = apply_base_rules(repository_path, base_rules)
    final_owner, override_desc = apply_override_rules(
        repository_path, language, base_owner, override_rules
    )

    manual = apply_manual_override(repository_path, manual_overrides)
    if manual:
        final_owner = manual
        override_desc = f"manual_override:{manual}"

    return OwnerResolution(
        repository=repository_path,
        base_owner=base_owner,
        override_applied=override_desc,
        final_owner=final_owner,
    )


# --- Seed data matching what's been confirmed so far ---
# Load these into the DB once via a seed script (see app/services/seed_rules.py)
SEED_BASE_RULES = [
    {"pattern": "taxtech/fatca", "match_type": "substring", "business_unit": "FATCA", "priority": 1, "active": True},
    {"pattern": "taxtech/whm", "match_type": "substring", "business_unit": "WHM", "priority": 2, "active": True},
    {"pattern": "taxtech/tdl", "match_type": "substring", "business_unit": "TDL", "priority": 3, "active": True},
    {"pattern": "taxtech/ust", "match_type": "substring", "business_unit": "USTax", "priority": 4, "active": True},
]

SEED_OVERRIDE_RULES = [
    # most-specific path matches first, general 'whm' last among path rules
    {"condition_type": "path_contains", "condition_value": "whm/fwt", "override_owner": "USTax", "priority": 1, "active": True},
    {"condition_type": "path_contains", "condition_value": "whm/recon", "override_owner": "USTax", "priority": 2, "active": True},
    {"condition_type": "path_contains", "condition_value": "whm", "override_owner": "WHM", "priority": 3, "active": True},  # PENDING CONFIRMATION
    {"condition_type": "language_equals", "condition_value": "Go", "override_owner": "DevOps", "priority": 4, "active": True},
    {"condition_type": "language_equals", "condition_value": "OS", "override_owner": "DevOps", "priority": 5, "active": True},
]
