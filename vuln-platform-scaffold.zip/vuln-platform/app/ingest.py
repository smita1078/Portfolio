"""
Run this to ingest one weekly report file.

USAGE:
    python -m app.ingest --source cm --file uploads/cm_report_17aug.xlsx --date 2026-08-17
    python -m app.ingest --source prisma --file uploads/prisma_report_17aug.xlsx --date 2026-08-17
    python -m app.ingest --source oss --file uploads/oss_report_17aug.xlsx --date 2026-08-17

Run it three times (once per source) each week, pointing at that week's file.
Nothing is overwritten - each run creates a new scan_batch row, so history
for every prior week stays intact.
"""
import argparse
import sys
from datetime import datetime

from app.database import SessionLocal, engine, Base
from app.models.scan_batch import ScanBatch
from app.models.audit_log import IngestionAuditLog
from app.parsers.cm_parser import parse_cm_report
from app.parsers.prisma_parser import parse_prisma_report
from app.parsers.oss_parser import parse_oss_report
from app.services.rule_loader import load_base_rules, load_override_rules, load_manual_overrides


def ingest(source: str, file_path: str, report_date: str, uploaded_by: str = None, sheet_name: str = None):
    Base.metadata.create_all(bind=engine)  # safe no-op if tables already exist
    db = SessionLocal()

    try:
        report_date_parsed = datetime.strptime(report_date, "%Y-%m-%d").date()

        batch = ScanBatch(
            source=source,
            report_date=report_date_parsed,
            file_name=file_path.split("/")[-1],
            uploaded_by=uploaded_by,
            raw_file_ref=file_path,
            status="processing",
        )
        db.add(batch)
        db.flush()  # get batch.id without committing yet

        print(f"Created scan_batch id={batch.id} for source={source}, report_date={report_date_parsed}")

        if source == "cm":
            findings = parse_cm_report(file_path, batch.id, sheet_name=sheet_name)
            db.add_all(findings)

        elif source == "prisma":
            base_rules = load_base_rules(db)
            override_rules = load_override_rules(db)
            manual_overrides = load_manual_overrides(db)
            if not base_rules:
                print("WARNING: no owner_base_rule rows found — did you run "
                      "'python -m app.services.seed_rules' first? All owners will default to DevOps.")
            findings = parse_prisma_report(
                file_path, batch.id, base_rules, override_rules, manual_overrides, sheet_name=sheet_name
            )
            db.add_all(findings)

        elif source == "oss":
            findings = parse_oss_report(file_path, batch.id, sheet_name=sheet_name)
            db.add_all(findings)

        else:
            raise ValueError(f"Unknown source '{source}' — must be one of: cm, prisma, oss")

        batch.row_count = len(findings)
        batch.status = "completed"

        db.add(IngestionAuditLog(
            scan_batch_id=batch.id,
            action="upload",
            actor=uploaded_by or "cli",
            detail={"source": source, "file": file_path, "row_count": len(findings)},
        ))

        db.commit()
        print(f"Done. Inserted {len(findings)} rows from {file_path} into source='{source}'.")

    except Exception as e:
        db.rollback()
        print(f"FAILED: {e}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ingest one weekly source report.")
    parser.add_argument("--source", required=True, choices=["cm", "prisma", "oss"])
    parser.add_argument("--file", required=True, help="Path to the xlsx file")
    parser.add_argument("--date", required=True, help="Report date, format YYYY-MM-DD (e.g. 2026-08-17)")
    parser.add_argument("--sheet", required=False, default=None, help="Sheet name, if not the first/default sheet")
    parser.add_argument("--by", required=False, default=None, help="Your name/id, for the audit log")
    args = parser.parse_args()

    ingest(source=args.source, file_path=args.file, report_date=args.date, uploaded_by=args.by, sheet_name=args.sheet)
