# Vulnerability & Cyber Hygiene Platform — v1 Scaffold

Runs entirely locally with SQLite — no server, no company DB provisioning needed.
The whole "database" is a file (`vuln_platform.db`) created next to this project.

## What's built so far

- **Database models** (`app/models/`) — all 14 tables: scan_batch, cm_finding,
  prisma_finding, oss_component_snapshot, owner rule tables (base/override/manual),
  per-source weekly snapshot + delta tables, audit log.
- **Prisma owner rule engine** (`app/rules/owner_engine.py`) — the 3-stage
  pipeline (base pattern match → language/path overrides → one-off manual
  overrides), fully unit tested (`tests/test_owner_engine.py`, 8 passing tests
  including the priority-ordering edge cases we caught during design review).
- **Parsers** (`app/parsers/`) — one per source (CM, Prisma, OSS), each reading
  the exact columns identified in the source-to-column mapping doc.
- **Seed script** (`app/services/seed_rules.py`) — loads the confirmed owner
  rules into the DB.

## Setup

```bash
# 1. Create a virtual environment (keeps this isolated from other Python projects)
python -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
# If your company requires an internal PyPI mirror, add: --index-url <your-mirror-url>

# 3. Create the database and seed the owner rules
python -m app.services.seed_rules
```

This creates `vuln_platform.db` in the project folder and populates the owner
rule tables. Re-run this any time the rule logic changes.

## Running the tests

```bash
python -m pytest tests/ -v
```

Currently covers the owner rule engine end to end, including the specific
`whm/fwt` vs. general `whm` precedence bug we caught during design.

## Where files should live

Since `vuln_platform.db` will contain the same sensitive data as your source
xlsx reports (hostnames, repo paths, CVEs), store the project folder wherever
your company's data policy says those reports should live — not somewhere more
exposed than the originals.

## Next steps (not yet built)

1. **Ingestion endpoint / script** — wire the parsers up to actually read an
   uploaded file, create a `scan_batch` row, insert the parsed findings, commit.
2. **Weekly snapshot/delta computation** — the service that runs after each
   ingestion to populate `*_weekly_snapshot` and `*_weekly_delta` tables.
3. **FastAPI routes** (`app/api/`) — expose upload, search/filter, and
   comparator endpoints.
4. **Frontend** — dashboard, search/filter UI, week comparator, rule admin screen.

## Known open items (need team confirmation before this is production-safe)

1. Whether CM's own `Finding ID` is stable across re-scans (currently we
   rebuild the natural key from CVE + hostname instead of trusting it — see
   `app/parsers/cm_parser.py::build_natural_key`).
2. What the plain `whm` path (no `/fwt` or `/recon`) actually resolves to —
   currently seeded as `WHM`, flagged in `app/rules/owner_engine.py`.
3. Precedence between language-based and path-based override rules when a
   repo matches both.
4. How `report_date` is determined from the uploaded file (file name? a cell
   in the sheet? upload date?).
5. How `environment` is captured for Prisma and OSS rows (CM has an obvious
   candidate column; the other two don't, per the samples reviewed so far).

Test files can be run against your real (scrubbed) sample data once you're
ready to validate the parsers against actual report structure.
